
  # Finance Generator App

  This is a code bundle for Finance Generator App. The original project is available at https://www.figma.com/design/6XNvmfHQZAgi0L0rtEHYK8/Finance-Generator-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  