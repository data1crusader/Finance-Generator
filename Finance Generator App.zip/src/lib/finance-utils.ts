export interface Expense {
  id: string;
  amount: number;
  description: string;
  date: string; // ISO format YYYY-MM-DD
  category?: string;
}

export interface MonthlyData {
  monthKey: string; // Format: YYYY-MM
  allowance: number;
  expenses: Expense[];
}

export interface FinanceData {
  [monthKey: string]: MonthlyData;
}

export const getCurrentMonthKey = (): string => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
};

export const getMonthKeyFromDate = (date: Date): string => {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
};

export const formatMonthKey = (monthKey: string): string => {
  const [year, month] = monthKey.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
};

export const calculateTotalExpenses = (expenses: Expense[]): number => {
  return expenses.reduce((sum, expense) => sum + expense.amount, 0);
};

export const calculateRemainingBalance = (allowance: number, expenses: Expense[]): number => {
  return allowance - calculateTotalExpenses(expenses);
};

export const getExpensesByDate = (expenses: Expense[]): Map<string, number> => {
  const expenseMap = new Map<string, number>();
  expenses.forEach(expense => {
    const current = expenseMap.get(expense.date) || 0;
    expenseMap.set(expense.date, current + expense.amount);
  });
  return expenseMap;
};

export const saveToLocalStorage = (data: FinanceData, userId: string): void => {
  localStorage.setItem(`financeData_${userId}`, JSON.stringify(data));
};

export const loadFromLocalStorage = (userId: string): FinanceData => {
  const stored = localStorage.getItem(`financeData_${userId}`);
  return stored ? JSON.parse(stored) : {};
};

export const saveCurrencyToLocalStorage = (currency: string, userId: string): void => {
  localStorage.setItem(`selectedCurrency_${userId}`, currency);
};

export const loadCurrencyFromLocalStorage = (userId: string): string => {
  return localStorage.getItem(`selectedCurrency_${userId}`) || 'USD';
};

export const getCurrencySymbol = (currencyCode: string): string => {
  const currencySymbols: { [key: string]: string } = {
    'USD': '$',
    'EUR': '€',
    'GBP': '£',
    'JPY': '¥',
    'CNY': '¥',
    'INR': '₹',
    'AUD': 'A$',
    'CAD': 'C$',
    'CHF': 'Fr',
    'KRW': '₩',
    'SGD': 'S$',
    'MXN': 'MX$',
    'BRL': 'R$',
    'ZAR': 'R',
    'AED': 'د.إ',
  };
  return currencySymbols[currencyCode] || '$';
};

export const formatCurrency = (amount: number, currencyCode: string): string => {
  const symbol = getCurrencySymbol(currencyCode);
  return `${symbol}${amount.toFixed(2)}`;
};