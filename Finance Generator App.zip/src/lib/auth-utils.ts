export interface User {
  id: string;
  email: string;
  name: string;
}

export interface UserCredentials {
  email: string;
  password: string;
  name?: string;
}

const USERS_KEY = 'finance_tracker_users';
const CURRENT_USER_KEY = 'finance_tracker_current_user';

// Get all registered users from localStorage
function getUsers(): Record<string, { password: string; name: string }> {
  const usersData = localStorage.getItem(USERS_KEY);
  return usersData ? JSON.parse(usersData) : {};
}

// Save users to localStorage
function saveUsers(users: Record<string, { password: string; name: string }>) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

// Sign up a new user
export function signUp({ email, password, name }: UserCredentials): { success: boolean; error?: string; user?: User } {
  if (!email || !password || !name) {
    return { success: false, error: 'All fields are required' };
  }

  if (!email.includes('@')) {
    return { success: false, error: 'Please enter a valid email address' };
  }

  if (password.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters' };
  }

  const users = getUsers();

  if (users[email]) {
    return { success: false, error: 'An account with this email already exists' };
  }

  // Store user credentials
  users[email] = { password, name };
  saveUsers(users);

  // Create user object
  const user: User = {
    id: email,
    email,
    name,
  };

  // Set as current user
  setCurrentUser(user);

  return { success: true, user };
}

// Sign in an existing user
export function signIn({ email, password }: UserCredentials): { success: boolean; error?: string; user?: User } {
  if (!email || !password) {
    return { success: false, error: 'Email and password are required' };
  }

  const users = getUsers();
  const userRecord = users[email];

  if (!userRecord || userRecord.password !== password) {
    return { success: false, error: 'Invalid email or password' };
  }

  const user: User = {
    id: email,
    email,
    name: userRecord.name,
  };

  setCurrentUser(user);

  return { success: true, user };
}

// Sign out the current user
export function signOut() {
  localStorage.removeItem(CURRENT_USER_KEY);
}

// Get the current logged-in user
export function getCurrentUser(): User | null {
  const userData = localStorage.getItem(CURRENT_USER_KEY);
  return userData ? JSON.parse(userData) : null;
}

// Set the current user
function setCurrentUser(user: User) {
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
}

// Get user-specific data key
export function getUserDataKey(userId: string): string {
  return `finance_tracker_data_${userId}`;
}

// Get user-specific currency key
export function getUserCurrencyKey(userId: string): string {
  return `finance_tracker_currency_${userId}`;
}
