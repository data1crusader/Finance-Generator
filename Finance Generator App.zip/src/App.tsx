import { useState, useEffect } from 'react';
import { AuthPage } from './components/AuthPage';
import { AddExpense } from './components/AddExpense';
import { MonthlyBudget } from './components/MonthlyBudget';
import { ExpenseList } from './components/ExpenseList';
import { SpendingChart } from './components/SpendingChart';
import { MonthSelector } from './components/MonthSelector';
import { Dashboard } from './components/Dashboard';
import { CurrencySelector } from './components/CurrencySelector';
import { Button } from './components/ui/button';
import { LogOut } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { 
  FinanceData, 
  Expense, 
  getCurrentMonthKey, 
  saveToLocalStorage, 
  loadFromLocalStorage,
  saveCurrencyToLocalStorage,
  loadCurrencyFromLocalStorage
} from './lib/finance-utils';
import { getCurrentUser, signOut, User } from './lib/auth-utils';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => getCurrentUser());
  const [financeData, setFinanceData] = useState<FinanceData>({});
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonthKey());
  const [currency, setCurrency] = useState('USD');

  // Load user-specific data when user changes
  useEffect(() => {
    if (currentUser) {
      setFinanceData(loadFromLocalStorage(currentUser.id));
      setCurrency(loadCurrencyFromLocalStorage(currentUser.id));
    } else {
      setFinanceData({});
      setCurrency('USD');
    }
  }, [currentUser]);

  // Initialize current month if it doesn't exist
  useEffect(() => {
    if (currentUser) {
      const currentMonth = getCurrentMonthKey();
      if (!financeData[currentMonth]) {
        setFinanceData(prev => ({
          ...prev,
          [currentMonth]: {
            monthKey: currentMonth,
            allowance: 0,
            expenses: [],
          },
        }));
      }
    }
  }, [currentUser]);

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (currentUser) {
      saveToLocalStorage(financeData, currentUser.id);
    }
  }, [financeData, currentUser]);

  // Save currency to localStorage whenever it changes
  useEffect(() => {
    if (currentUser) {
      saveCurrencyToLocalStorage(currency, currentUser.id);
    }
  }, [currency, currentUser]);

  const handleAuthSuccess = () => {
    setCurrentUser(getCurrentUser());
  };

  const handleLogout = () => {
    signOut();
    setCurrentUser(null);
    setFinanceData({});
    setCurrency('USD');
    setSelectedMonth(getCurrentMonthKey());
  };

  // Show auth page if not logged in
  if (!currentUser) {
    return <AuthPage onAuthSuccess={handleAuthSuccess} />;
  }

  const currentMonthData = financeData[selectedMonth] || {
    monthKey: selectedMonth,
    allowance: 0,
    expenses: [],
  };

  const handleSetAllowance = (amount: number) => {
    setFinanceData(prev => ({
      ...prev,
      [selectedMonth]: {
        ...currentMonthData,
        allowance: amount,
      },
    }));
  };

  const handleAddExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      ...expense,
      id: Date.now().toString(),
    };

    setFinanceData(prev => ({
      ...prev,
      [selectedMonth]: {
        ...currentMonthData,
        expenses: [...currentMonthData.expenses, newExpense],
      },
    }));
  };

  const handleDeleteExpense = (id: string) => {
    setFinanceData(prev => ({
      ...prev,
      [selectedMonth]: {
        ...currentMonthData,
        expenses: currentMonthData.expenses.filter(e => e.id !== id),
      },
    }));
  };

  const availableMonths = Object.keys(financeData).length > 0 
    ? Object.keys(financeData) 
    : [getCurrentMonthKey()];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-4 md:p-8 max-w-7xl">
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-2">
            <div>
              <h1 className="text-4xl">Finance Tracker</h1>
              <p className="text-muted-foreground">
                Welcome back, {currentUser.name}! Manage your monthly allowance and track your expenses
              </p>
            </div>
            <div className="flex items-center gap-4">
              <CurrencySelector 
                selectedCurrency={currency}
                onCurrencyChange={setCurrency}
              />
              <Button onClick={handleLogout} variant="outline" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {availableMonths.length > 0 && (
            <MonthSelector
              currentMonth={selectedMonth}
              availableMonths={availableMonths}
              onMonthChange={setSelectedMonth}
            />
          )}

          <MonthlyBudget
            currentAllowance={currentMonthData.allowance}
            onSetAllowance={handleSetAllowance}
            currency={currency}
          />

          {currentMonthData.allowance > 0 && (
            <>
              <Dashboard
                allowance={currentMonthData.allowance}
                expenses={currentMonthData.expenses}
                currency={currency}
              />

              <Tabs defaultValue="add" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="add">Add Expense</TabsTrigger>
                  <TabsTrigger value="history">History</TabsTrigger>
                  <TabsTrigger value="charts">Charts</TabsTrigger>
                </TabsList>

                <TabsContent value="add" className="mt-6">
                  <AddExpense onAddExpense={handleAddExpense} currency={currency} />
                </TabsContent>

                <TabsContent value="history" className="mt-6">
                  <ExpenseList
                    expenses={currentMonthData.expenses}
                    onDeleteExpense={handleDeleteExpense}
                    currency={currency}
                  />
                </TabsContent>

                <TabsContent value="charts" className="mt-6">
                  {currentMonthData.expenses.length > 0 ? (
                    <SpendingChart
                      expenses={currentMonthData.expenses}
                      monthKey={selectedMonth}
                      currency={currency}
                    />
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      Add some expenses to see charts
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
