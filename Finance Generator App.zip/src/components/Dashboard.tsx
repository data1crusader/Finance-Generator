import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { TrendingDown, TrendingUp, DollarSign } from 'lucide-react';
import { calculateTotalExpenses, calculateRemainingBalance, formatCurrency } from '../lib/finance-utils';
import { Expense } from '../lib/finance-utils';

interface DashboardProps {
  allowance: number;
  expenses: Expense[];
  currency: string;
}

export function Dashboard({ allowance, expenses, currency }: DashboardProps) {
  const totalSpent = calculateTotalExpenses(expenses);
  const remaining = calculateRemainingBalance(allowance, expenses);
  const percentageSpent = allowance > 0 ? (totalSpent / allowance) * 100 : 0;
  const isOverBudget = remaining < 0;

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>Total Budget</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{formatCurrency(allowance, currency)}</div>
          <p className="text-muted-foreground">Monthly allowance</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>Total Spent</CardTitle>
          <TrendingDown className="h-4 w-4 text-destructive" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl">{formatCurrency(totalSpent, currency)}</div>
          <p className="text-muted-foreground">
            {percentageSpent.toFixed(1)}% of budget
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>Remaining</CardTitle>
          <TrendingUp className={`h-4 w-4 ${isOverBudget ? 'text-destructive' : 'text-green-500'}`} />
        </CardHeader>
        <CardContent>
          <div className={`text-2xl ${isOverBudget ? 'text-destructive' : ''}`}>
            {formatCurrency(remaining, currency)}
          </div>
          <p className="text-muted-foreground">
            {isOverBudget ? 'Over budget' : 'Available to spend'}
          </p>
        </CardContent>
      </Card>

      <Card className="md:col-span-3">
        <CardHeader>
          <CardTitle>Budget Progress</CardTitle>
          <CardDescription>
            {isOverBudget 
              ? `You've exceeded your budget by ${formatCurrency(Math.abs(remaining), currency)}`
              : `You have ${(100 - percentageSpent).toFixed(1)}% of your budget remaining`
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Progress 
            value={Math.min(percentageSpent, 100)} 
            className="h-4"
          />
        </CardContent>
      </Card>
    </div>
  );
}