import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { formatMonthKey } from '../lib/finance-utils';

interface MonthSelectorProps {
  currentMonth: string;
  availableMonths: string[];
  onMonthChange: (monthKey: string) => void;
}

export function MonthSelector({ currentMonth, availableMonths, onMonthChange }: MonthSelectorProps) {
  const sortedMonths = [...availableMonths].sort().reverse();
  const currentIndex = sortedMonths.indexOf(currentMonth);
  
  const canGoPrevious = currentIndex < sortedMonths.length - 1;
  const canGoNext = currentIndex > 0;

  const handlePrevious = () => {
    if (canGoPrevious) {
      onMonthChange(sortedMonths[currentIndex + 1]);
    }
  };

  const handleNext = () => {
    if (canGoNext) {
      onMonthChange(sortedMonths[currentIndex - 1]);
    }
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            size="icon"
            onClick={handlePrevious}
            disabled={!canGoPrevious}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          <div className="text-center">
            <h2 className="text-2xl">{formatMonthKey(currentMonth)}</h2>
            <p className="text-muted-foreground">
              {currentIndex + 1} of {sortedMonths.length} months
            </p>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={handleNext}
            disabled={!canGoNext}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
