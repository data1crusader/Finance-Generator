import { useState } from 'react';
import { Login } from './Login';
import { SignUp } from './SignUp';
import { Wallet } from 'lucide-react';

interface AuthPageProps {
  onAuthSuccess: () => void;
}

export function AuthPage({ onAuthSuccess }: AuthPageProps) {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-primary text-primary-foreground p-4 rounded-full">
              <Wallet className="h-12 w-12" />
            </div>
          </div>
          <h1 className="text-4xl mb-2">Finance Tracker</h1>
          <p className="text-muted-foreground">
            {isLogin ? 'Sign in to manage your finances' : 'Create an account to get started'}
          </p>
        </div>

        {isLogin ? (
          <Login
            onLogin={onAuthSuccess}
            onSwitchToSignUp={() => setIsLogin(false)}
          />
        ) : (
          <SignUp
            onSignUp={onAuthSuccess}
            onSwitchToLogin={() => setIsLogin(true)}
          />
        )}
      </div>
    </div>
  );
}
