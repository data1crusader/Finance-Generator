import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Wallet } from 'lucide-react';
import { formatCurrency } from '../lib/finance-utils';

interface MonthlyBudgetProps {
  currentAllowance: number;
  onSetAllowance: (amount: number) => void;
  currency: string;
}

export function MonthlyBudget({ currentAllowance, onSetAllowance, currency }: MonthlyBudgetProps) {
  const [allowance, setAllowance] = useState(currentAllowance.toString());
  const [isEditing, setIsEditing] = useState(currentAllowance === 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const amountNum = parseFloat(allowance);
    if (isNaN(amountNum) || amountNum <= 0) {
      return;
    }

    onSetAllowance(amountNum);
    setIsEditing(false);
  };

  if (!isEditing && currentAllowance > 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Monthly Allowance</CardTitle>
          <CardDescription>Your budget for this month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Wallet className="h-8 w-8 text-primary" />
              <div>
                <p className="text-muted-foreground">Budget</p>
                <p className="text-2xl">{formatCurrency(currentAllowance, currency)}</p>
              </div>
            </div>
            <Button variant="outline" onClick={() => setIsEditing(true)}>
              Edit
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Set Monthly Allowance</CardTitle>
        <CardDescription>Enter your budget for this month</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="allowance">Monthly Budget</Label>
            <Input
              id="allowance"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={allowance}
              onChange={(e) => setAllowance(e.target.value)}
              required
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              <Wallet className="mr-2 h-4 w-4" />
              Set Budget
            </Button>
            {currentAllowance > 0 && (
              <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}