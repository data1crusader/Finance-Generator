import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Expense, getExpensesByDate, getCurrencySymbol } from '../lib/finance-utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface SpendingChartProps {
  expenses: Expense[];
  monthKey: string;
  currency: string;
}

export function SpendingChart({ expenses, monthKey, currency }: SpendingChartProps) {
  const expensesByDate = getExpensesByDate(expenses);
  const currencySymbol = getCurrencySymbol(currency);
  
  // Get all days in the month
  const [year, month] = monthKey.split('-').map(Number);
  const daysInMonth = new Date(year, month, 0).getDate();
  
  // Create data for all days
  const chartData = [];
  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const amount = expensesByDate.get(dateStr) || 0;
    chartData.push({
      day: day,
      amount: amount,
      date: dateStr,
    });
  }

  // Calculate cumulative spending
  let cumulative = 0;
  const cumulativeData = chartData.map(item => {
    cumulative += item.amount;
    return {
      day: item.day,
      cumulative: cumulative,
    };
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Daily Spending</CardTitle>
          <CardDescription>Amount spent each day</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="day" 
                label={{ value: 'Day of Month', position: 'insideBottom', offset: -5 }}
              />
              <YAxis 
                label={{ value: `Amount (${currencySymbol})`, angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                formatter={(value: number) => `${currencySymbol}${value.toFixed(2)}`}
                labelFormatter={(label) => `Day ${label}`}
              />
              <Bar dataKey="amount" fill="hsl(var(--primary))" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cumulative Spending</CardTitle>
          <CardDescription>Total spending over time</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={cumulativeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="day" 
                label={{ value: 'Day of Month', position: 'insideBottom', offset: -5 }}
              />
              <YAxis 
                label={{ value: `Total Spent (${currencySymbol})`, angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                formatter={(value: number) => `${currencySymbol}${value.toFixed(2)}`}
                labelFormatter={(label) => `Day ${label}`}
              />
              <Line 
                type="monotone" 
                dataKey="cumulative" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}