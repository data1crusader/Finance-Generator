import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Trash2 } from 'lucide-react';
import { Expense, formatCurrency } from '../lib/finance-utils';

interface ExpenseListProps {
  expenses: Expense[];
  onDeleteExpense: (id: string) => void;
  currency: string;
}

export function ExpenseList({ expenses, onDeleteExpense, currency }: ExpenseListProps) {
  const sortedExpenses = [...expenses].sort((a, b) => {
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Expense History</CardTitle>
        <CardDescription>
          {expenses.length} {expenses.length === 1 ? 'expense' : 'expenses'} recorded
        </CardDescription>
      </CardHeader>
      <CardContent>
        {sortedExpenses.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            No expenses recorded yet
          </p>
        ) : (
          <div className="space-y-2">
            {sortedExpenses.map((expense) => (
              <div
                key={expense.id}
                className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
              >
                <div className="flex-1">
                  <p>{expense.description}</p>
                  <p className="text-muted-foreground">
                    {new Date(expense.date).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <p className="text-destructive">
                    -{formatCurrency(expense.amount, currency)}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDeleteExpense(expense.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}